package part02;

public interface Vendible {
	public String deliver();
}
